package sentenciasSeleccion;

import apiJava.CALIFICACION;

public class OperadoresLogicos {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
	}

}
